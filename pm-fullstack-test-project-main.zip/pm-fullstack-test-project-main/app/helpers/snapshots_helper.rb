module SnapshotsHelper
end
