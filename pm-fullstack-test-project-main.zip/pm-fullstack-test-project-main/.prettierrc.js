module.exports = {
  printWidth: 80,
  tabWidth: 2,
  trailingComma: "es5",
  arrowParens: "avoid",
  semi: false,
  singleQuote: true,
  jsxSingleQuote: true,
  bracketSpacing: true,
  jsxBracketSameLine: false,
};
